/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define IO_RA0_TRIS                 TRISAbits.TRISA0
#define IO_RA0_LAT                  LATAbits.LATA0
#define IO_RA0_PORT                 PORTAbits.RA0
#define IO_RA0_WPU                  WPUAbits.WPUA0
#define IO_RA0_OD                   ODCONAbits.ODCA0
#define IO_RA0_ANS                  ANSELAbits.ANSELA0
#define IO_RA0_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define IO_RA0_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define IO_RA0_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define IO_RA0_GetValue()           PORTAbits.RA0
#define IO_RA0_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define IO_RA0_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define IO_RA0_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define IO_RA0_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define IO_RA0_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define IO_RA0_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define IO_RA0_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define IO_RA0_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define INT_OUT_TRIS                 TRISAbits.TRISA1
#define INT_OUT_LAT                  LATAbits.LATA1
#define INT_OUT_PORT                 PORTAbits.RA1
#define INT_OUT_WPU                  WPUAbits.WPUA1
#define INT_OUT_OD                   ODCONAbits.ODCA1
#define INT_OUT_ANS                  ANSELAbits.ANSELA1
#define INT_OUT_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define INT_OUT_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define INT_OUT_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define INT_OUT_GetValue()           PORTAbits.RA1
#define INT_OUT_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define INT_OUT_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define INT_OUT_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define INT_OUT_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define INT_OUT_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define INT_OUT_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define INT_OUT_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define INT_OUT_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RA2 aliases
#define IO_RA2_TRIS                 TRISAbits.TRISA2
#define IO_RA2_LAT                  LATAbits.LATA2
#define IO_RA2_PORT                 PORTAbits.RA2
#define IO_RA2_WPU                  WPUAbits.WPUA2
#define IO_RA2_OD                   ODCONAbits.ODCA2
#define IO_RA2_ANS                  ANSELAbits.ANSELA2
#define IO_RA2_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define IO_RA2_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define IO_RA2_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define IO_RA2_GetValue()           PORTAbits.RA2
#define IO_RA2_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define IO_RA2_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define IO_RA2_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define IO_RA2_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define IO_RA2_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define IO_RA2_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define IO_RA2_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define IO_RA2_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RB4 aliases
#define NANO_BUTTON_TRIS                 TRISBbits.TRISB4
#define NANO_BUTTON_LAT                  LATBbits.LATB4
#define NANO_BUTTON_PORT                 PORTBbits.RB4
#define NANO_BUTTON_WPU                  WPUBbits.WPUB4
#define NANO_BUTTON_OD                   ODCONBbits.ODCB4
#define NANO_BUTTON_ANS                  ANSELBbits.ANSELB4
#define NANO_BUTTON_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define NANO_BUTTON_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define NANO_BUTTON_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define NANO_BUTTON_GetValue()           PORTBbits.RB4
#define NANO_BUTTON_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define NANO_BUTTON_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define NANO_BUTTON_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define NANO_BUTTON_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define NANO_BUTTON_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define NANO_BUTTON_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define NANO_BUTTON_SetAnalogMode()      do { ANSELBbits.ANSELB4 = 1; } while(0)
#define NANO_BUTTON_SetDigitalMode()     do { ANSELBbits.ANSELB4 = 0; } while(0)

// get/set RC6 aliases
#define IO_RC6_TRIS                 TRISCbits.TRISC6
#define IO_RC6_LAT                  LATCbits.LATC6
#define IO_RC6_PORT                 PORTCbits.RC6
#define IO_RC6_WPU                  WPUCbits.WPUC6
#define IO_RC6_OD                   ODCONCbits.ODCC6
#define IO_RC6_ANS                  ANSELCbits.ANSELC6
#define IO_RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define IO_RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define IO_RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define IO_RC6_GetValue()           PORTCbits.RC6
#define IO_RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define IO_RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define IO_RC6_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define IO_RC6_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define IO_RC6_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define IO_RC6_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define IO_RC6_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define IO_RC6_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define IO_RC7_TRIS                 TRISCbits.TRISC7
#define IO_RC7_LAT                  LATCbits.LATC7
#define IO_RC7_PORT                 PORTCbits.RC7
#define IO_RC7_WPU                  WPUCbits.WPUC7
#define IO_RC7_OD                   ODCONCbits.ODCC7
#define IO_RC7_ANS                  ANSELCbits.ANSELC7
#define IO_RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define IO_RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define IO_RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define IO_RC7_GetValue()           PORTCbits.RC7
#define IO_RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define IO_RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define IO_RC7_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define IO_RC7_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define IO_RC7_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define IO_RC7_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define IO_RC7_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define IO_RC7_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD1 aliases
#define BUTTON_TRIS                 TRISDbits.TRISD1
#define BUTTON_LAT                  LATDbits.LATD1
#define BUTTON_PORT                 PORTDbits.RD1
#define BUTTON_WPU                  WPUDbits.WPUD1
#define BUTTON_OD                   ODCONDbits.ODCD1
#define BUTTON_ANS                  ANSELDbits.ANSELD1
#define BUTTON_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define BUTTON_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define BUTTON_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define BUTTON_GetValue()           PORTDbits.RD1
#define BUTTON_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define BUTTON_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define BUTTON_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define BUTTON_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define BUTTON_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define BUTTON_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define BUTTON_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define BUTTON_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define RED_LED_TRIS                 TRISDbits.TRISD2
#define RED_LED_LAT                  LATDbits.LATD2
#define RED_LED_PORT                 PORTDbits.RD2
#define RED_LED_WPU                  WPUDbits.WPUD2
#define RED_LED_OD                   ODCONDbits.ODCD2
#define RED_LED_ANS                  ANSELDbits.ANSELD2
#define RED_LED_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define RED_LED_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define RED_LED_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define RED_LED_GetValue()           PORTDbits.RD2
#define RED_LED_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define RED_LED_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define RED_LED_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define RED_LED_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define RED_LED_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define RED_LED_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define RED_LED_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define RED_LED_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RF0 aliases
#define IO_RF0_TRIS                 TRISFbits.TRISF0
#define IO_RF0_LAT                  LATFbits.LATF0
#define IO_RF0_PORT                 PORTFbits.RF0
#define IO_RF0_WPU                  WPUFbits.WPUF0
#define IO_RF0_OD                   ODCONFbits.ODCF0
#define IO_RF0_ANS                  ANSELFbits.ANSELF0
#define IO_RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_RF0_GetValue()           PORTFbits.RF0
#define IO_RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define IO_RF1_TRIS                 TRISFbits.TRISF1
#define IO_RF1_LAT                  LATFbits.LATF1
#define IO_RF1_PORT                 PORTFbits.RF1
#define IO_RF1_WPU                  WPUFbits.WPUF1
#define IO_RF1_OD                   ODCONFbits.ODCF1
#define IO_RF1_ANS                  ANSELFbits.ANSELF1
#define IO_RF1_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define IO_RF1_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define IO_RF1_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define IO_RF1_GetValue()           PORTFbits.RF1
#define IO_RF1_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define IO_RF1_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define IO_RF1_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define IO_RF1_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define IO_RF1_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define IO_RF1_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define IO_RF1_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define IO_RF1_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

// get/set RF3 aliases
#define NANO_LED_TRIS                 TRISFbits.TRISF3
#define NANO_LED_LAT                  LATFbits.LATF3
#define NANO_LED_PORT                 PORTFbits.RF3
#define NANO_LED_WPU                  WPUFbits.WPUF3
#define NANO_LED_OD                   ODCONFbits.ODCF3
#define NANO_LED_ANS                  ANSELFbits.ANSELF3
#define NANO_LED_SetHigh()            do { LATFbits.LATF3 = 1; } while(0)
#define NANO_LED_SetLow()             do { LATFbits.LATF3 = 0; } while(0)
#define NANO_LED_Toggle()             do { LATFbits.LATF3 = ~LATFbits.LATF3; } while(0)
#define NANO_LED_GetValue()           PORTFbits.RF3
#define NANO_LED_SetDigitalInput()    do { TRISFbits.TRISF3 = 1; } while(0)
#define NANO_LED_SetDigitalOutput()   do { TRISFbits.TRISF3 = 0; } while(0)
#define NANO_LED_SetPullup()          do { WPUFbits.WPUF3 = 1; } while(0)
#define NANO_LED_ResetPullup()        do { WPUFbits.WPUF3 = 0; } while(0)
#define NANO_LED_SetPushPull()        do { ODCONFbits.ODCF3 = 0; } while(0)
#define NANO_LED_SetOpenDrain()       do { ODCONFbits.ODCF3 = 1; } while(0)
#define NANO_LED_SetAnalogMode()      do { ANSELFbits.ANSELF3 = 1; } while(0)
#define NANO_LED_SetDigitalMode()     do { ANSELFbits.ANSELF3 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/