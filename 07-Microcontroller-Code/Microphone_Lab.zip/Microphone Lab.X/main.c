#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/dac/dac1.h"
#include "mcc_generated_files/uart/uart1.h"
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    adc_result_t analog_in = 0;
    uint8_t analog_out = 0;
    uint16_t counter = 0;

    SYSTEM_Initialize();
    ADC_Initialize();

    RED_LED_SetLow();
    NANO_LED_SetHigh();
    INT_OUT_SetLow();

    while (1)
    {
        // PCB button and red LED
        if (BUTTON_GetValue() == 0)
        {
            RED_LED_SetHigh();
        }
        else
        {
            RED_LED_SetLow();
        }

        // Nano button and yellow LED
        if (NANO_BUTTON_GetValue() == 0)
        {
            NANO_LED_SetLow();
        }
        else
        {
            NANO_LED_SetHigh();
        }

        // Microphone ADC input
        ADC_ChannelSelect(ADC_CHANNEL_ANA0);
        ADC_ConversionStart();

        while (!ADC_IsConversionDone());

        analog_in = ADC_ConversionResultGet();

        // Convert 12-bit ADC to 8-bit DAC
        analog_out = analog_in >> 4;

        // Output microphone signal on RA2
        DAC1_SetOutput(analog_out);

        // UART communication
        counter++;

        if (counter >= 2000)
        {
            counter = 0;

            // Send microphone reading to teammate
            if (UART1_IsTxReady())
            {
                UART1_Write(analog_out);
            }

            // Display microphone readings in PuTTY
            printf("ADC: %u | DAC: %u\r\n",
                   (unsigned int)analog_in,
                   (unsigned int)analog_out);
        }
    }

    return 0;
}